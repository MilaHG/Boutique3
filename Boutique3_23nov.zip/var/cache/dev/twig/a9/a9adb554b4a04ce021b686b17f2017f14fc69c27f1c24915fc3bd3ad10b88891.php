<?php

/* @Boutique/Admin/show_produit.html.twig */
class __TwigTemplate_0d8dd095bf89928228e06c517b8f4199065436207b19c47aa644c153336835f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Boutique/Admin/show_produit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Admin/show_produit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Admin/show_produit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h1 class=\"mt-4\">";
        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        echo "</h1>

        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 9
            echo "            <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 12
            echo "            <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "
    <div class=\"row\">
        <div class=\"col-12\">
            <p style=\"text-align: right;\"><strong>Nombre de produits dans la boutique : ";
        // line 17
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["produits"] ?? $this->getContext($context, "produits"))), "html", null, true);
        echo " </strong></p>
            ";
        // line 19
        echo "        </div>

        <table class=\"table table-striped table-hover table-dark\">
            <thead>
                <tr>
                    ";
        // line 25
        echo "                    <th></th>
                    <th>#</th>
                    <th>Réf.</th>
                    <th>Catégorie</th>
                    <th>Titre</th>
                    <th>Couleur</th>
                    <th>Taille</th>
                    <th>Public</th>
                    <th>Description</th>
                    <th>Prix</th>
                    <th>Stock</th>
                    <th colspan=\"3\">Actions</th>
                </tr>
            </thead>
            <tbody>
            ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["produits"] ?? $this->getContext($context, "produits")));
        foreach ($context['_seq'] as $context["_key"] => $context["pdt"]) {
            // line 41
            echo "                <tr>
                    <td><img class=\"img-fluid\" style=\"max-height: 60px\" src=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/photo/" . $this->getAttribute($context["pdt"], "photo", array()))), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "titre", array()), "html", null, true);
            echo "\"></td>
                    <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "idProduit", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "reference", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "categorie", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "titre", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "couleur", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "taille", array()), "html", null, true);
            echo "</td>

                    ";
            // line 50
            if (($this->getAttribute($context["pdt"], "public", array()) == "m")) {
                // line 51
                echo "                         <td>Homme</td>
                    ";
            } elseif (($this->getAttribute(            // line 52
$context["pdt"], "public", array()) == "f")) {
                // line 53
                echo "                        <td>Femme</td>
                    ";
            } else {
                // line 55
                echo "                        <td>Mixte</td>
                    ";
            }
            // line 57
            echo "
                    <td>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "description", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 59
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["pdt"], "prix", array()), 2, ",", " "), "html", null, true);
            echo "€</td>
                    <td>";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["pdt"], "stock", array()), "html", null, true);
            echo "</td>

                    ";
            // line 63
            echo "                    <td><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("produit", array("id" => $this->getAttribute($context["pdt"], "idProduit", array()))), "html", null, true);
            echo "\" target=\"_blank\"><i class=\"text-success fas fa-eye\"></i></a></td>
                    <td><a href=\"";
            // line 64
            echo "\" target=\"_blank\"><i class=\"text-warning fas fa-edit\"></i></a></td>
                    <td><a href=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_produit", array("id" => $this->getAttribute($context["pdt"], "idProduit", array()))), "html", null, true);
            echo "\" target=\"_blank\"><i class=\"text-danger fas fa-trash-alt\"></i></a></td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pdt'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 68
        echo "            </tbody>
        </table>
    </div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Boutique/Admin/show_produit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  220 => 68,  211 => 65,  208 => 64,  203 => 63,  198 => 60,  194 => 59,  190 => 58,  187 => 57,  183 => 55,  179 => 53,  177 => 52,  174 => 51,  172 => 50,  167 => 48,  163 => 47,  159 => 46,  155 => 45,  151 => 44,  147 => 43,  141 => 42,  138 => 41,  134 => 40,  117 => 25,  110 => 19,  106 => 17,  101 => 14,  92 => 12,  87 => 11,  78 => 9,  74 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

    {% block title %}{{ title }}{% endblock %}

{% block content %}
    <h1 class=\"mt-4\">{{ title }}</h1>

        {% for message in app.session.flashbag.get('success') %}
            <div class=\"alert alert-success\">{{ message }}</div>
        {% endfor %}
        {% for message in app.session.flashbag.get('error') %}
            <div class=\"alert alert-danger\">{{ message }}</div>
        {% endfor %}

    <div class=\"row\">
        <div class=\"col-12\">
            <p style=\"text-align: right;\"><strong>Nombre de produits dans la boutique : {{ produits | length }} </strong></p>
            {# {{ produits | length }} => <?php count(\$tab); sizeof(\$tab) ?> #}
        </div>

        <table class=\"table table-striped table-hover table-dark\">
            <thead>
                <tr>
                    {#<th>Photo</th>#}
                    <th></th>
                    <th>#</th>
                    <th>Réf.</th>
                    <th>Catégorie</th>
                    <th>Titre</th>
                    <th>Couleur</th>
                    <th>Taille</th>
                    <th>Public</th>
                    <th>Description</th>
                    <th>Prix</th>
                    <th>Stock</th>
                    <th colspan=\"3\">Actions</th>
                </tr>
            </thead>
            <tbody>
            {% for pdt in produits %}
                <tr>
                    <td><img class=\"img-fluid\" style=\"max-height: 60px\" src=\"{{ asset('/photo/' ~ pdt.photo) }}\" alt=\"{{ pdt.titre }}\"></td>
                    <td>{{ pdt.idProduit }}</td>
                    <td>{{ pdt.reference }}</td>
                    <td>{{ pdt.categorie }}</td>
                    <td>{{ pdt.titre }}</td>
                    <td>{{ pdt.couleur }}</td>
                    <td>{{ pdt.taille }}</td>

                    {% if pdt.public == 'm' %}
                         <td>Homme</td>
                    {% elseif pdt.public == 'f' %}
                        <td>Femme</td>
                    {% else %}
                        <td>Mixte</td>
                    {% endif %}

                    <td>{{ pdt.description }}</td>
                    <td>{{ pdt.prix | number_format(2, ',', ' ') }}€</td>
                    <td>{{ pdt.stock }}</td>

                    {#(td>a[target=\"_blank\" href]>i.fas)*3#}
                    <td><a href=\"{{ path('produit', {'id' : pdt.idProduit}) }}\" target=\"_blank\"><i class=\"text-success fas fa-eye\"></i></a></td>
                    <td><a href=\"{# {{ path('update_produit', {'id' : pdt.idProduit}) }} #}\" target=\"_blank\"><i class=\"text-warning fas fa-edit\"></i></a></td>
                    <td><a href=\"{{ path('delete_produit', {'id' : pdt.idProduit}) }}\" target=\"_blank\"><i class=\"text-danger fas fa-trash-alt\"></i></a></td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>


{% endblock %}", "@Boutique/Admin/show_produit.html.twig", "C:\\xampp\\htdocs\\Symfony\\Boutique3\\src\\BoutiqueBundle\\Resources\\views\\Admin\\show_produit.html.twig");
    }
}
