<?php

/* @Boutique/Admin/show_membre.html.twig */
class __TwigTemplate_2ba3d4b8aa6421acc0f4773fbbb363792edc0d0bded4a20dbc67c98aa808b30e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Boutique/Admin/show_membre.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Admin/show_membre.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Admin/show_membre.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h1 class=\"mt-4\">";
        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        echo "</h1>

    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 9
            echo "        <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 12
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "
    <div class=\"row\">
        <div class=\"col-12\">
            <p style=\"text-align: right;\"><strong>Nombre de membres du site : ";
        // line 17
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["membres"] ?? $this->getContext($context, "membres"))), "html", null, true);
        echo " </strong></p>
            ";
        // line 19
        echo "        </div>

        <table class=\"table table-striped table-hover table-dark\">
            <thead>
            <tr>
                <th>#</th>
                <th>Pseudo</th>
                <th>MDP</th>
                <th>Nom</th>
                ";
        // line 29
        echo "                <th>Email</th>
                ";
        // line 31
        echo "                <th>Ville</th>
                <th>Code postal</th>
                ";
        // line 34
        echo "                <th>Statut</th>
                <th colspan=\"2\">Actions</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["membres"] ?? $this->getContext($context, "membres")));
        foreach ($context['_seq'] as $context["_key"] => $context["mber"]) {
            // line 40
            echo "                <tr>
                    <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "idMembre", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "pseudo", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "mdp", array()), "html", null, true);
            echo "</td>

                    ";
            // line 45
            if (($this->getAttribute($context["mber"], "civilite", array()) == "m")) {
                // line 46
                echo "                    <td>M. ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "prenom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "nom", array()), "html", null, true);
                echo "</td>
                    ";
            } else {
                // line 48
                echo "                    <td>Mme ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "prenom", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "nom", array()), "html", null, true);
                echo "</td>
                    ";
            }
            // line 50
            echo "                    ";
            // line 51
            echo "                    ";
            // line 52
            echo "                    <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "email", array()), "html", null, true);
            echo "</td>

                    ";
            // line 55
            echo "                        ";
            // line 56
            echo "                    ";
            // line 57
            echo "                        ";
            // line 58
            echo "                    ";
            // line 59
            echo "
                    <td>";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["mber"], "ville", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 61
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["mber"], "codePostal", array()), 0, ",", " "), "html", null, true);
            echo "</td>
                    ";
            // line 63
            echo "
                    ";
            // line 64
            if (($this->getAttribute($context["mber"], "statut", array()) == 1)) {
                // line 65
                echo "                        <td class=\"text-info\">ADMIN</td>
                    ";
            } else {
                // line 67
                echo "                        <td>Client</td>
                    ";
            }
            // line 69
            echo "
                    ";
            // line 71
            echo "
                    <td><a href=\"";
            // line 72
            echo "\" target=\"_blank\"><i class=\"text-warning fas fa-edit\"></i></a></td>
                    <td><a href=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_membre", array("id" => $this->getAttribute($context["mber"], "idMembre", array()))), "html", null, true);
            echo "\" target=\"_blank\"><i class=\"text-danger fas
                    fa-trash-alt\"></i></a></td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mber'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "            </tbody>
        </table>
    </div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Boutique/Admin/show_membre.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  234 => 77,  224 => 73,  221 => 72,  218 => 71,  215 => 69,  211 => 67,  207 => 65,  205 => 64,  202 => 63,  198 => 61,  194 => 60,  191 => 59,  189 => 58,  187 => 57,  185 => 56,  183 => 55,  177 => 52,  175 => 51,  173 => 50,  165 => 48,  157 => 46,  155 => 45,  150 => 43,  146 => 42,  142 => 41,  139 => 40,  135 => 39,  128 => 34,  124 => 31,  121 => 29,  110 => 19,  106 => 17,  101 => 14,  92 => 12,  87 => 11,  78 => 9,  74 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

    {% block title %}{{ title }}{% endblock %}

{% block content %}
    <h1 class=\"mt-4\">{{ title }}</h1>

    {% for message in app.session.flashbag.get('success') %}
        <div class=\"alert alert-success\">{{ message }}</div>
    {% endfor %}
    {% for message in app.session.flashbag.get('error') %}
        <div class=\"alert alert-danger\">{{ message }}</div>
    {% endfor %}

    <div class=\"row\">
        <div class=\"col-12\">
            <p style=\"text-align: right;\"><strong>Nombre de membres du site : {{ membres | length }} </strong></p>
            {# {{ produits | length }} => <?php count(\$tab); sizeof(\$tab) ?> #}
        </div>

        <table class=\"table table-striped table-hover table-dark\">
            <thead>
            <tr>
                <th>#</th>
                <th>Pseudo</th>
                <th>MDP</th>
                <th>Nom</th>
                {#<th>Prénom</th>#}
                <th>Email</th>
                {#<th>Civilité</th>#}
                <th>Ville</th>
                <th>Code postal</th>
                {#<th>Adresse</th>#}
                <th>Statut</th>
                <th colspan=\"2\">Actions</th>
            </tr>
            </thead>
            <tbody>
            {% for mber in membres %}
                <tr>
                    <td>{{ mber.idMembre }}</td>
                    <td>{{ mber.pseudo }}</td>
                    <td>{{ mber.mdp }}</td>

                    {% if mber.civilite == 'm' %}
                    <td>M. {{ mber.prenom }} {{ mber.nom }}</td>
                    {% else %}
                    <td>Mme {{ mber.prenom }} {{ mber.nom }}</td>
                    {% endif %}
                    {#<td>{{ mber.nom }}</td>#}
                    {#<td>{{ mber.prenom }}</td>#}
                    <td>{{ mber.email }}</td>

                    {#{% if mber.civilite == 'm' %}#}
                        {#<td>Homme</td>#}
                    {#{% else %}#}
                        {#<td>Femme</td>#}
                    {#{% endif %}#}

                    <td>{{ mber.ville }}</td>
                    <td>{{ mber.codePostal | number_format(0, ',', ' ') }}</td>
                    {#<td>{{ mber.adresse }}</td>#}

                    {% if mber.statut == 1 %}
                        <td class=\"text-info\">ADMIN</td>
                    {% else %}
                        <td>Client</td>
                    {% endif %}

                    {#(td>a[target=\"_blank\" href]>i.fas)*3#}

                    <td><a href=\"{# {{ path('update_membre', {'id' : mber.idMembre}) }} #}\" target=\"_blank\"><i class=\"text-warning fas fa-edit\"></i></a></td>
                    <td><a href=\"{{ path('delete_membre', {'id' : mber.idMembre}) }}\" target=\"_blank\"><i class=\"text-danger fas
                    fa-trash-alt\"></i></a></td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>


{% endblock %}", "@Boutique/Admin/show_membre.html.twig", "C:\\xampp\\htdocs\\Symfony\\Boutique3\\src\\BoutiqueBundle\\Resources\\views\\Admin\\show_membre.html.twig");
    }
}
