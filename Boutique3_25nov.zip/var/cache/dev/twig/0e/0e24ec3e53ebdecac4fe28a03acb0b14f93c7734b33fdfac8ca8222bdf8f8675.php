<?php

/* @Boutique/Membre/form.html.twig */
class __TwigTemplate_5a9f7bc19fa9ce2417acb7746616e1c70a40e88199b8fd2e394d72bb426d2afd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Boutique/Membre/form.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Membre/form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Membre/form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "
\t<h1> Formulaire d'inscription</h1>
\t";
        // line 9
        echo "\t";
        // line 10
        echo "\t";
        // line 11
        echo "\t\t";
        // line 12
        echo "\t";
        // line 13
        echo "\t";
        // line 14
        echo "
\t<div class=\"col-6 m-auto mt-5\">
\t\t";
        // line 17
        echo "\t\t";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["membreForm"] ?? $this->getContext($context, "membreForm")), 'form_start');
        echo "
\t\t";
        // line 19
        echo "\t\t";
        // line 20
        echo "\t\t";
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["membreForm"] ?? $this->getContext($context, "membreForm")), 'errors');
        echo "
\t\t<div class=\"form-group\">
\t\t\t";
        // line 22
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "pseudo", array()), 'row');
        echo "
\t\t</div>
\t\t<hr>
\t\t";
        // line 26
        echo "\t\t<div class=\"form-group\">
\t\t\t";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "prenom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre prenom")));
        echo "
\t\t\t";
        // line 28
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "prenom", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 31
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "nom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre nom")));
        echo "
\t\t\t";
        // line 32
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "nom", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 35
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "mdp", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre mot de passe")));
        echo "
\t\t\t";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "mdp", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "email", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre email")));
        echo "
\t\t\t";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "email", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 43
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "civilite", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
\t\t\t";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "civilite", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "ville", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre ville")));
        echo "
\t\t\t";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "ville", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 51
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "codePostal", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre code postal")));
        echo "
\t\t\t";
        // line 52
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "codePostal", array()), 'errors');
        echo "
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t";
        // line 55
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "adresse", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Votre adresse")));
        echo "
\t\t\t";
        // line 56
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["membreForm"] ?? $this->getContext($context, "membreForm")), "adresse", array()), 'errors');
        echo "
\t\t</div>

\t\t";
        // line 60
        echo "\t\t";
        // line 61
        echo "\t\t";
        // line 62
        echo "\t\t\t";
        // line 63
        echo "\t\t\t";
        // line 64
        echo "\t\t";
        // line 65
        echo "\t\t";
        // line 66
        echo "
\t\t";
        // line 67
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["membreForm"] ?? $this->getContext($context, "membreForm")), 'rest');
        echo "
\t\t";
        // line 69
        echo "\t\t";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["membreForm"] ?? $this->getContext($context, "membreForm")), 'form_end');
        echo "
\t</div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Boutique/Membre/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 69,  184 => 67,  181 => 66,  179 => 65,  177 => 64,  175 => 63,  173 => 62,  171 => 61,  169 => 60,  163 => 56,  159 => 55,  153 => 52,  149 => 51,  143 => 48,  139 => 47,  133 => 44,  129 => 43,  123 => 40,  119 => 39,  113 => 36,  109 => 35,  103 => 32,  99 => 31,  93 => 28,  89 => 27,  86 => 26,  80 => 22,  74 => 20,  72 => 19,  67 => 17,  63 => 14,  61 => 13,  59 => 12,  57 => 11,  55 => 10,  53 => 9,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{# {% block title %}Inscription Membre{% endblock %} #}

{% block content %}

\t<h1> Formulaire d'inscription</h1>
\t{# cf. inscription.html.twig - méthode 1 #}
\t{# Méthode très simple qui génère le formulaire entièrement #}
\t{#<div class=\"col-6 m-auto mt-5\">#}
\t\t{#{{form(membreForm)}}#}
\t{#</div>#}
\t{# FIN cf. inscription.html.twig - méthode 1 #}

\t<div class=\"col-6 m-auto mt-5\">
\t\t{# Méthode pour générer nous même les champs du formulaire #}
\t\t{{ form_start(membreForm) }}
\t\t{# On pourrait vouloir récupérer toutes les erreurs du formulaire en haut #}
\t\t{# Méthode 1 #}
\t\t{{ form_errors(membreForm) }}
\t\t<div class=\"form-group\">
\t\t\t{{ form_row(membreForm.pseudo)}}
\t\t</div>
\t\t<hr>
\t\t{# Methode 2 #}
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.prenom, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre prenom'}})}}
\t\t\t{{form_errors(membreForm.prenom)}}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.nom, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre nom'}})}}
\t\t\t{{ form_errors(membreForm.nom) }}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.mdp, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre mot de passe'}})}}
\t\t\t{{ form_errors(membreForm.mdp) }}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.email, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre email'}})}}
\t\t\t{{ form_errors(membreForm.email) }}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.civilite, {'attr' : {'class' : 'form-control'}})}}
\t\t\t{{ form_errors(membreForm.civilite) }}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.ville, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre ville'}})}}
\t\t\t{{ form_errors(membreForm.ville) }}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.codePostal, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre code postal'}})}}
\t\t\t{{ form_errors(membreForm.codePostal) }}
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t{{form_widget(membreForm.adresse, {'attr' : {'class' : 'form-control', 'placeholder' : 'Votre adresse'}})}}
\t\t\t{{ form_errors(membreForm.adresse) }}
\t\t</div>

\t\t{#, {'attr' : {'class' : 'btn btn-info btn-block', 'value' : 'Envoi'}}#}
\t\t{#{% block button_widget %}#}
\t\t{#<div class=\"btn btn-info btn-block\">#}
\t\t\t{#{% block button_widget %}{% endblock %}#}
\t\t\t{#{% block submit_widget %}{% endblock %}#}
\t\t{#</div>#}
\t\t{#{% endblock %}#}

\t\t{{ form_rest(membreForm) }}
\t\t{# form_rest esn très important car il génère le jeton CSRF et gère la sécurité #}
\t\t{{ form_end(membreForm) }}
\t</div>


{% endblock %}", "@Boutique/Membre/form.html.twig", "/Applications/MAMP/htdocs/symfony/Boutique3/src/BoutiqueBundle/Resources/views/Membre/form.html.twig");
    }
}
