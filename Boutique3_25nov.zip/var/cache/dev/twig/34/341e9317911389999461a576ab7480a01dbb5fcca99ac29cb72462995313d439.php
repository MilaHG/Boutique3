<?php

/* @Boutique/Admin/show_commande.html.twig */
class __TwigTemplate_80fb7ab36b2d05cde9ce933c27c5a6b06be2b3dd5b56c12f91d82f4eeee9cafb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Boutique/Admin/show_commande.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Admin/show_commande.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Admin/show_commande.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h1 class=\"mt-4\">";
        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        echo "</h1>

    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 9
            echo "        <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 12
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "
    <div class=\"row\">
        <div class=\"col-12\">
            <p style=\"text-align: right;\"><strong>Nombre de commandes passées : ";
        // line 17
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["commandes"] ?? $this->getContext($context, "commandes"))), "html", null, true);
        echo " </strong></p>
            ";
        // line 19
        echo "        </div>

        <table class=\"table table-striped table-hover table-dark\">
            <thead>
            <tr>
                <th class=\"text-primary\">#</th>
                <th>Réf. membre</th>
                <th>Date</th>
                <th>Montant</th>
                <th>Etat</th>
                <th colspan=\"2\">Actions</th>
            </tr>
            </thead>
            <tbody>

            ";
        // line 34
        if (($context["commandes"] ?? $this->getContext($context, "commandes"))) {
            // line 35
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["commandes"] ?? $this->getContext($context, "commandes")));
            foreach ($context['_seq'] as $context["_key"] => $context["cde"]) {
                // line 36
                echo "                    <tr>
                        <td class=\"text-primary\">";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute($context["cde"], "idCommande", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 38
                echo twig_escape_filter($this->env, $this->getAttribute($context["cde"], "idMembre", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 39
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["cde"], "dateEnregistrement", array()), "d-m-Y h:i:s"), "html", null, true);
                echo "</td>

                        <td>";
                // line 41
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["cde"], "montant", array()), 0, ",", " "), "html", null, true);
                echo "€</td>

                        ";
                // line 43
                if (($this->getAttribute($context["cde"], "etat", array()) == 1)) {
                    // line 44
                    echo "                            <td class=\"text-info\">En préparation</td>
                        ";
                } elseif (($this->getAttribute(                // line 45
$context["cde"], "etat", array()) == 2)) {
                    // line 46
                    echo "                            <td class=\"text-info\">Expédié</td>
                        ";
                } else {
                    // line 48
                    echo "                            <td class=\"text-success\">Livré</td>
                        ";
                }
                // line 50
                echo "
                        ";
                // line 52
                echo "
                        <td><a href=\"";
                // line 53
                echo "\" target=\"_blank\"><i class=\"text-warning fas fa-edit\"></i></a></td>
                        <td><a href=\"";
                // line 54
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete_commande", array("id" => $this->getAttribute($context["cde"], "idCommande", array()))), "html", null, true);
                echo "\" target=\"_blank\"><i class=\"text-danger fas
                        fa-trash-alt\"></i></a></td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cde'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 58
            echo "            ";
        } else {
            // line 59
            echo "                <tr><td class=\"text-center text-warning\" colspan=\"6\">Aucune commande n'a été passée</td></tr>
            ";
        }
        // line 61
        echo "            </tbody>
        </table>
    </div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Boutique/Admin/show_commande.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  196 => 61,  192 => 59,  189 => 58,  179 => 54,  176 => 53,  173 => 52,  170 => 50,  166 => 48,  162 => 46,  160 => 45,  157 => 44,  155 => 43,  150 => 41,  145 => 39,  141 => 38,  137 => 37,  134 => 36,  129 => 35,  127 => 34,  110 => 19,  106 => 17,  101 => 14,  92 => 12,  87 => 11,  78 => 9,  74 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

    {% block title %}{{ title }}{% endblock %}

{% block content %}
    <h1 class=\"mt-4\">{{ title }}</h1>

    {% for message in app.session.flashbag.get('success') %}
        <div class=\"alert alert-success\">{{ message }}</div>
    {% endfor %}
    {% for message in app.session.flashbag.get('error') %}
        <div class=\"alert alert-danger\">{{ message }}</div>
    {% endfor %}

    <div class=\"row\">
        <div class=\"col-12\">
            <p style=\"text-align: right;\"><strong>Nombre de commandes passées : {{ commandes | length }} </strong></p>
            {# {{ produits | length }} => <?php count(\$tab); sizeof(\$tab) ?> #}
        </div>

        <table class=\"table table-striped table-hover table-dark\">
            <thead>
            <tr>
                <th class=\"text-primary\">#</th>
                <th>Réf. membre</th>
                <th>Date</th>
                <th>Montant</th>
                <th>Etat</th>
                <th colspan=\"2\">Actions</th>
            </tr>
            </thead>
            <tbody>

            {% if commandes %}
                {% for cde in commandes %}
                    <tr>
                        <td class=\"text-primary\">{{ cde.idCommande }}</td>
                        <td>{{ cde.idMembre }}</td>
                        <td>{{ cde.dateEnregistrement | date(\"d-m-Y h:i:s\")}}</td>

                        <td>{{ cde.montant | number_format(0, ',', ' ') }}€</td>

                        {% if cde.etat == 1 %}
                            <td class=\"text-info\">En préparation</td>
                        {% elseif cde.etat == 2 %}
                            <td class=\"text-info\">Expédié</td>
                        {% else %}
                            <td class=\"text-success\">Livré</td>
                        {% endif %}

                        {#(td>a[target=\"_blank\" href]>i.fas)*3#}

                        <td><a href=\"{# {{ path('update_commande', {'id' : cde.idMembre}) }} #}\" target=\"_blank\"><i class=\"text-warning fas fa-edit\"></i></a></td>
                        <td><a href=\"{{ path('delete_commande', {'id' : cde.idCommande}) }}\" target=\"_blank\"><i class=\"text-danger fas
                        fa-trash-alt\"></i></a></td>
                    </tr>
                {% endfor %}
            {% else %}
                <tr><td class=\"text-center text-warning\" colspan=\"6\">Aucune commande n'a été passée</td></tr>
            {% endif %}
            </tbody>
        </table>
    </div>


{% endblock %}", "@Boutique/Admin/show_commande.html.twig", "C:\\xampp\\htdocs\\Symfony\\Boutique3\\src\\BoutiqueBundle\\Resources\\views\\Admin\\show_commande.html.twig");
    }
}
