-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Nov 26, 2018 at 08:20 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `site_commerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(3) NOT NULL,
  `id_membre` int(3) DEFAULT NULL,
  `montant` int(3) NOT NULL,
  `date_enregistrement` datetime NOT NULL,
  `etat` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `details_commande`
--

CREATE TABLE `details_commande` (
  `id_details_commande` int(3) NOT NULL,
  `id_commande` int(3) DEFAULT NULL,
  `id_produit` int(3) DEFAULT NULL,
  `quantite` int(3) NOT NULL,
  `prix` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `membre`
--

CREATE TABLE `membre` (
  `id_membre` int(3) NOT NULL,
  `pseudo` varchar(20) CHARACTER SET latin1 NOT NULL,
  `mdp` varchar(32) CHARACTER SET latin1 NOT NULL,
  `nom` varchar(20) CHARACTER SET latin1 NOT NULL,
  `prenom` varchar(20) CHARACTER SET latin1 NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 NOT NULL,
  `civilite` varchar(1) CHARACTER SET latin1 NOT NULL,
  `ville` varchar(20) CHARACTER SET latin1 NOT NULL,
  `code_postal` int(5) NOT NULL,
  `adresse` varchar(50) CHARACTER SET latin1 NOT NULL,
  `statut` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membre`
--

INSERT INTO `membre` (`id_membre`, `pseudo`, `mdp`, `nom`, `prenom`, `email`, `civilite`, `ville`, `code_postal`, `adresse`, `statut`) VALUES
(1, 'admin', 'admin', 'Gauthier', 'Mila', 'moi@moi.fr', 'f', 'VLG', 92300, '9 allée Saint-Exupéry', 1);

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

CREATE TABLE `produit` (
  `reference` varchar(20) NOT NULL,
  `categorie` varchar(20) NOT NULL,
  `titre` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `couleur` varchar(20) NOT NULL,
  `taille` varchar(5) NOT NULL,
  `public` varchar(5) NOT NULL,
  `photo` varchar(250) DEFAULT NULL,
  `prix` float NOT NULL,
  `stock` int(3) NOT NULL,
  `id_produit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`reference`, `categorie`, `titre`, `description`, `couleur`, `taille`, `public`, `photo`, `prix`, `stock`, `id_produit`) VALUES
('0001', 'pantalon', 'Jean', 'jean bleu', 'bleu', 'S', 'f', 'ref0001-pantalon1.jpg', 89, 3, 1),
('0002', 'pantalon', 'pantalon blanc', 'pantalon blanc', 'blanc', 'S', 'f', 'ref0002-pantalon2.jpg', 74, 50, 2),
('0003', 'pull', 'pull blanc', 'pull blanc', 'blanc', 'S', 'f', 'ref0003-pull1.jpg', 50, 12, 3),
('0004', 'pull', 'pull gris', 'pull gris clair', 'gris', 'S', 'm', 'ref0004-pull2.jpg', 49, 36, 4),
('0005', 'robe', 'robe noire', 'pour vos soirées et cocktails', 'noir', 'S', 'f', 'ref0005-robe1.jpg', 99, 54, 5),
('0006', 'robe', 'robe rouge', 'robe de cocktail', 'rouge', 'S', 'f', 'ref0006-robe2.jpg', 79.9, 0, 6),
('0007', 'pull', 'pull', 'pull', 'blanc', 'L', 'm', 'ref0007-pull1.jpg', 49, 11, 7),
('0008', 'pantalon', 'pantalon flanelle', 'pantalon homme', 'noir', 'XL', 'm', 'ref0008-pull2.jpg', 39.5, 8, 8),
('0009', 'robe', 'robe de plage', 'robe de plage', 'bleu', 'M', 'f', 'ref009-robe1.jpg', 56, 4, 9),
('0010', 'robe', 'robe corail', 'robe orange corail', 'corail', 'L', 'f', 'ref0010-robe2.jpg', 67.8, 35, 10),
('0011', 'chaussure', 'tennis', 'tennis bleu et blanc', 'bleu', 'L', 'm', 'ref0011-pantalon2.jpg', 49.9, 8, 11),
('0012', 'chaussure', 'escarpins', 'chaussures élégantes', 'noir', 'S', 'f', 'ref0012-robe1.jpg', 46, 2, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`);

--
-- Indexes for table `details_commande`
--
ALTER TABLE `details_commande`
  ADD PRIMARY KEY (`id_details_commande`);

--
-- Indexes for table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`id_membre`);

--
-- Indexes for table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id_produit`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `details_commande`
--
ALTER TABLE `details_commande`
  MODIFY `id_details_commande` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `membre`
--
ALTER TABLE `membre`
  MODIFY `id_membre` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `produit`
--
ALTER TABLE `produit`
  MODIFY `id_produit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
