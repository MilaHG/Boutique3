<?php

/* layout.html.twig */
class __TwigTemplate_8d2113affc36479330e476a9617daef5340cbed3672e06d55ddce88d7507148c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">

    <title>Ma Boutique";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <!-- Bootstrap Core CSS -->
    <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">
    <!-- jQuery -->
    <script src=\"https://code.jquery.com/jquery-3.3.1.min.js\" integrity=\"sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=\" crossorigin=\"anonymous\"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
        <div class=\"container\">
            <!-- La marque -->
            <a href=\"\" class=\"navbar-brand\">MA BOUTIQUE</a>

            <!-- Le burger -->
            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#nav1\" aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>


            <!-- Le menu -->
            <div class=\"collapse navbar-collapse\" id=\"nav1\">
                <ul class=\"navbar-nav ml-auto\">
                    <li><a class=\"nav-link\" href=\"\">Boutique</a></li>
                    <li><a class=\"nav-link\" href=\"\">Profil</a></li>
                    <li><a class=\"nav-link\" href=\"\">Panier</a></li>
                    <li><a class=\"nav-link\" href=\"\">Connexion</a></li>
                    <li><a class=\"nav-link\" href=\"\">Inscription</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class=\"container\" style=\"min-height:80vh;\">
        <div class=\"row\">
            <div class=\"col-12\">
                <!-- ici le contenu spécifique de chaque page -->
                ";
        // line 45
        $this->displayBlock('content', $context, $blocks);
        // line 47
        echo "                ";
        // line 48
        echo "                ";
        // line 49
        echo "            </div><!-- .col-12 -->
        </div><!-- .row -->
    </div> <!-- .container -->
    <!-- footer -->
    <div class=\"container\">
        <hr>
        <footer>
            <div class=\"row text-center\">
                <div class=\"col\">
                    <p>Copyright &copy; Ma Boutique - 2018</p>
                </div>
            </div>
        </footer>
    </div><!-- .container -->
</body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 45
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 46
        echo "                ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  133 => 46,  124 => 45,  107 => 6,  82 => 49,  80 => 48,  78 => 47,  76 => 45,  34 => 6,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">

    <title>Ma Boutique{% block title %}{% endblock %}</title>
    <!-- Bootstrap Core CSS -->
    <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">
    <!-- jQuery -->
    <script src=\"https://code.jquery.com/jquery-3.3.1.min.js\" integrity=\"sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=\" crossorigin=\"anonymous\"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
        <div class=\"container\">
            <!-- La marque -->
            <a href=\"\" class=\"navbar-brand\">MA BOUTIQUE</a>

            <!-- Le burger -->
            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#nav1\" aria-controls=\"navbarResponsive\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>


            <!-- Le menu -->
            <div class=\"collapse navbar-collapse\" id=\"nav1\">
                <ul class=\"navbar-nav ml-auto\">
                    <li><a class=\"nav-link\" href=\"\">Boutique</a></li>
                    <li><a class=\"nav-link\" href=\"\">Profil</a></li>
                    <li><a class=\"nav-link\" href=\"\">Panier</a></li>
                    <li><a class=\"nav-link\" href=\"\">Connexion</a></li>
                    <li><a class=\"nav-link\" href=\"\">Inscription</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class=\"container\" style=\"min-height:80vh;\">
        <div class=\"row\">
            <div class=\"col-12\">
                <!-- ici le contenu spécifique de chaque page -->
                {% block content %}
                {% endblock %}
                {# Commentaire en twig invisible dans le code source #}
                {# Ce block content contient le contenu de la page demandée #}
            </div><!-- .col-12 -->
        </div><!-- .row -->
    </div> <!-- .container -->
    <!-- footer -->
    <div class=\"container\">
        <hr>
        <footer>
            <div class=\"row text-center\">
                <div class=\"col\">
                    <p>Copyright &copy; Ma Boutique - 2018</p>
                </div>
            </div>
        </footer>
    </div><!-- .container -->
</body>
</html>", "layout.html.twig", "C:\\xampp\\htdocs\\Symfonyvlg18\\Boutique3\\app\\Resources\\views\\layout.html.twig");
    }
}
