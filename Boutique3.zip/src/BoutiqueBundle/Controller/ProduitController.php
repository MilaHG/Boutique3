<?php

namespace BoutiqueBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
//use Symfony\Component\Routing\Annotation\Route;

class ProduitController extends Controller
{
    /**
     * @Route("/", name="home")
     */
    public function indexAction()
    {
        // récupérer les produits (BDD)
        // en attendant d'avoir vu Doctrine, on simule des fausses données avec un array
        $produits = array(
            0 => array(
                'id_produit' => 1,
                'reference' => '0001',
                'titre' => 'Jean',
                'categorie' => 'pantalon',
                'public' => 'f',
                'photo' => 'pantalon1.jpg',
                'description' => 'jean bleu',
                'couleur' => 'bleu',
                'taille' => 'S',
                'prix' => 89.00,
                'stock' => 3
            ),
            1 => array(
                'id_produit' => 2,
                'reference' => '0002',
                'titre' => 'Pull blanc',
                'categorie' => 'pull',
                'public' => 'f',
                'photo' => 'pull1.jpg',
                'description' => 'Pull doux et chaud couleur nuage',
                'couleur' => 'blanc',
                'taille' => 'L',
                'prix' => '119.50',
                'stock' => 8
            )
        );

        // récupérer les catégories du site (BDD)
        // en attendant d'avoir vu Doctrine, on simule des fausses données avec un array
        // SELECT DISTINCT categorie FROM produit
        $categories = array(
            0 => array(
                'categorie' => 'pull'
            ),
            1 => array(
                'categorie' => 'pantalon'
            )
        );

        // transmettre les produits à la vue
        $params = [
            'produits'  => $produits,
            'categories' => $categories,
            'title' => 'Accueil'
        ];

        // return $this->render('BoutiqueBundle:Default:index.html.twig'); // à changer par : (pb de version SF)
        return $this->render('@Boutique/Produit/index.html.twig', $params);
    }

#--------------------------------------#

    /**
     * @Route("/produit/{id}", name="produit")
     * www.boutique.com/produit/12
     */
    public function produitAction($id)
    {
        return $this->render('@Boutique/Produit/produit.html.twig');
// par convention non écrite on verrait dans les projets SF => return $this->render('@Boutique/Produit/show.html.twig');
    }

    /**
     * @Route("/categorie/{cat}", name="categorie")
     * www.boutique.com/categorie/tshirt
     */
    public function categorieAction($cat)
    {
        // récupérer les produits (BDD)
        // en attendant d'avoir vu Doctrine, on simule des fausses données avec un array
        $produits = array(
            0 => array(
                'id_produit' => 1,
                'reference' => '0001',
                'titre' => 'Jean',
                'categorie' => 'pantalon',
                'public' => 'f',
                'photo' => 'pantalon1.jpg',
                'description' => 'jean bleu',
                'couleur' => 'bleu',
                'taille' => 'S',
                'prix' => 89.00,
                'stock' => 3
            ),
            1 => array(
                'id_produit' => 2,
                'reference' => '0002',
                'titre' => 'Pull blanc',
                'categorie' => 'pull',
                'public' => 'f',
                'photo' => 'pull1.jpg',
                'description' => 'Pull doux et chaud couleur nuage',
                'couleur' => 'blanc',
                'taille' => 'L',
                'prix' => '119.50',
                'stock' => 8
            )
        );

        // récupérer les catégories du site (BDD)
        // en attendant d'avoir vu Doctrine, on simule des fausses données avec un array
        // SELECT DISTINCT categorie FROM produit
        $categories = array(
            0 => array(
                'categorie' => 'pull'
            ),
            1 => array(
                'categorie' => 'pantalon'
            )
        );

        // transmettre les produits à la vue
        $params = [
            'produits'  => $produits,
            'categories' => $categories,
            'cat' => $cat,
            'title' => 'Rayon : ' . $cat
        ];

        return $this->render('@Boutique/Produit/index.html.twig', $params);
    }




}
