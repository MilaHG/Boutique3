<?php

/* @Boutique/Produit/produit.html.twig */
class __TwigTemplate_9eedb21d74f18dc8a9197303b631cd896a09a2227136736cd110b4f1a8e71d02 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Boutique/Produit/produit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Produit/produit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Boutique/Produit/produit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <div class=\"row\">

        <div class=\"col-12\">
            <h1>";
        // line 9
        echo twig_escape_filter($this->env, ($context["title"] ?? $this->getContext($context, "title")), "html", null, true);
        echo "</h1>
        </div>

        <div class=\"col-md-8\">
            <img class=\"img-fluid\" src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/photo/" . $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "photo", array()))), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "titre", array()), "html", null, true);
        echo "\">
        </div>

        <div class=\"col-md-4\">
            <h3>Description</h3>
            <p>";
        // line 18
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "description", array())), "html", null, true);
        echo "</p>

            <h3>Détails</h3>
            <ul>
                ";
        // line 23
        echo "                <li>Catégorie : ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "categorie", array()), "html", null, true);
        echo "</li>
                <li>Couleur : ";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "couleur", array()), "html", null, true);
        echo "</li>
                <li>Taille : ";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "taille", array()), "html", null, true);
        echo "</li>
            </ul>
            <h4>Prix : ";
        // line 27
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "prix", array()), 2, ",", " "), "html", null, true);
        echo " €</h4>
            ";
        // line 29
        echo "
            ";
        // line 30
        if (($this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "stock", array()) > 0)) {
            // line 31
            echo "
                <form method=\"post\" action=\"panier.php\">

                    <input type=\"hidden\" name=\"id_produit\" value=\"\">
                    <select name=\"quantite\" class=\"custom-select col-sm-2\">
                        ";
            // line 37
            echo "                            ";
            // line 38
            echo "                                ";
            // line 39
            echo "                            ";
            // line 40
            echo "                        ";
            // line 41
            echo "                            ";
            // line 42
            echo "                            ";
            // line 43
            echo "                            ";
            // line 44
            echo "                        ";
            // line 45
            echo "
                        ";
            // line 47
            echo "
                        ";
            // line 48
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 5));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                if (($context["i"] <= $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "stock", array()))) {
                    // line 49
                    echo "                            <option>";
                    echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                    echo "</option>
                        ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "
                    </select>

                    <input type=\"submit\" name=\"ajout_panier\" value=\"Ajouter au panier\" class=\"btn alert-warning col-sm-8 ml-2\">

                </form>
                <p>Nombre de produit(s) disponible(s) : ";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "stock", array()), "html", null, true);
            echo "</p>

            ";
        } else {
            // line 60
            echo "                <p>Produit en rupture de stock !</p>

            ";
        }
        // line 63
        echo "
            <p>
                <a href=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("categorie", array("cat" => $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "categorie", array()))), "html", null, true);
        echo "\">Retour vers la catégorie \"";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute(($context["produit"] ?? $this->getContext($context, "produit")), "categorie", array())), "html", null, true);
        echo "\"</a>
            </p>


        </div>
    </div><!-- .row -->

        ";
        // line 73
        echo "
        ";
        // line 74
        if ((isset($context["suggestions"]) || array_key_exists("suggestions", $context))) {
            // line 75
            echo "        ";
            // line 76
            echo "            <hr>
            <div class=\"row\">
            <div class=\"col-12\">
                <h3>Suggestions de produits</h3>
            </div>
            <div class=\"card-deck mt-2 ml-1\">
                ";
            // line 82
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["suggestions"] ?? $this->getContext($context, "suggestions")));
            foreach ($context['_seq'] as $context["_key"] => $context["sug"]) {
                // line 83
                echo "                <div class=\"card text-center\">
                    <a href=\"";
                // line 84
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("produit", array("id" => $this->getAttribute($context["sug"], "idProduit", array()))), "html", null, true);
                echo "\">
                        <img src=\"";
                // line 85
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/photo/" . $this->getAttribute($context["sug"], "photo", array()))), "html", null, true);
                echo "\" alt=\"\" class=\"card-img-top img-fluid\" style=\"width: 200px;\">
                    </a>
                    <div class=\"card-footer alert-warning\">";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute($context["sug"], "titre", array()), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["sug"], "prix", array()), "html", null, true);
                echo "€</div>
                </div>  ";
                // line 89
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sug'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 90
            echo "            </div> ";
            // line 91
            echo "

        ";
        }
        // line 94
        echo "
    </div><!-- .row -->



    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Boutique/Produit/produit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  249 => 94,  244 => 91,  242 => 90,  236 => 89,  230 => 87,  225 => 85,  221 => 84,  218 => 83,  214 => 82,  206 => 76,  204 => 75,  202 => 74,  199 => 73,  187 => 65,  183 => 63,  178 => 60,  172 => 57,  164 => 51,  154 => 49,  149 => 48,  146 => 47,  143 => 45,  141 => 44,  139 => 43,  137 => 42,  135 => 41,  133 => 40,  131 => 39,  129 => 38,  127 => 37,  120 => 31,  118 => 30,  115 => 29,  111 => 27,  106 => 25,  102 => 24,  97 => 23,  90 => 18,  80 => 13,  73 => 9,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block title %}{{ title }}{% endblock %}

    {% block content %}
    <div class=\"row\">

        <div class=\"col-12\">
            <h1>{{ title }}</h1>
        </div>

        <div class=\"col-md-8\">
            <img class=\"img-fluid\" src=\"{{ asset('/photo/' ~ produit.photo) }}\" alt=\"{{ produit.titre }}\">
        </div>

        <div class=\"col-md-4\">
            <h3>Description</h3>
            <p>{{ produit.description | capitalize }}</p>

            <h3>Détails</h3>
            <ul>
                {#{% for produit in produits %}#}
                <li>Catégorie : {{ produit.categorie }}</li>
                <li>Couleur : {{ produit.couleur }}</li>
                <li>Taille : {{ produit.taille }}</li>
            </ul>
            <h4>Prix : {{ produit.prix|number_format(2, ',', ' ') }} €</h4>
            {# 12000.54 => 12 000,54 #}

            {% if produit.stock > 0 %}

                <form method=\"post\" action=\"panier.php\">

                    <input type=\"hidden\" name=\"id_produit\" value=\"\">
                    <select name=\"quantite\" class=\"custom-select col-sm-2\">
                        {#{% if produit.stock >= 5 %}#}
                            {#{% for i in 1..5 %}#}
                                {#<option>{{ i }}</option>#}
                            {#{% endfor %}#}
                        {#{% else %}#}
                            {#{% for i in 1..produit.stock %}#}
                            {#<option>{{ i }}</option>#}
                            {#{% endfor %}#}
                        {#{% endif %}#}

                        {# ces 2 blocs font la même chose, écrits différemment #}

                        {% for i in 1..5 if i <= produit.stock %}
                            <option>{{ i }}</option>
                        {% endfor %}

                    </select>

                    <input type=\"submit\" name=\"ajout_panier\" value=\"Ajouter au panier\" class=\"btn alert-warning col-sm-8 ml-2\">

                </form>
                <p>Nombre de produit(s) disponible(s) : {{ produit.stock }}</p>

            {% else %}
                <p>Produit en rupture de stock !</p>

            {% endif %}

            <p>
                <a href=\"{{ path('categorie', {'cat' : produit.categorie}) }}\">Retour vers la catégorie \"{{ produit.categorie|capitalize }}\"</a>
            </p>


        </div>
    </div><!-- .row -->

        {# Vignettes produits - Suggestions #}

        {%  if suggestions is defined %}
        {# is defined / is not null => isset #}
            <hr>
            <div class=\"row\">
            <div class=\"col-12\">
                <h3>Suggestions de produits</h3>
            </div>
            <div class=\"card-deck mt-2 ml-1\">
                {% for sug in suggestions %}
                <div class=\"card text-center\">
                    <a href=\"{{ path('produit', {'id' : sug.idProduit}) }}\">
                        <img src=\"{{ asset('/photo/' ~ sug.photo) }}\" alt=\"\" class=\"card-img-top img-fluid\" style=\"width: 200px;\">
                    </a>
                    <div class=\"card-footer alert-warning\">{{ sug.titre }} - {{ sug.prix }}€</div>
                </div>  {# end div.card.text-center #}
                {% endfor %}
            </div> {# end div.card-deck #}


        {% endif %}

    </div><!-- .row -->



    {% endblock %}", "@Boutique/Produit/produit.html.twig", "C:\\xampp\\htdocs\\Symfony\\Boutique3\\src\\BoutiqueBundle\\Resources\\views\\Produit\\produit.html.twig");
    }
}
