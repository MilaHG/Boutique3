<?php
/**
 * Created by PhpStorm.
 * User: Mila
 * Date: 20/11/2018
 * Time: 16:51
 */

namespace BoutiqueBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
//use Symfony\Component\Routing\Annotation\Route;

use BoutiqueBundle\Entity\Produit;
use BoutiqueBundle\Entity\Membre;
use BoutiqueBundle\Entity\Commande;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;


class AdminController extends Controller
{

    // affiche tous les produits dans un tableau
    /**
     * @Route("/admin/show_produits" name="show_produits")
     */
    public function adminShowProduitsAction()
    {
        
    }
#--------------------------------------------#
    // supprime un produit via son ID et retourne à show_produit
    /**
     * @Route("/admin/delete_produit/{id}" name="delete_produit")
     */
    public function adminDeleteProduitAction($id)
    {

    }
#--------------------------------------------#
    // affiche toutes les commandes dans un tableau
    /**
     * @Route("/admin/show_commandes" name="show_commandes")
     */
    public function adminShowCommandesAction()
    {

    }

#--------------------------------------------#
    // supprime une commande via son ID et retourne à show_commandes
    /**
     * @Route("/admin/delete_commande/{id} name="delete_commande")
     */
    public function adminDeleteCommande($id)
    {

    }

#--------------------------------------------#
    // affiche tous les membres dans un tableau
    /**
     * @Route("/admin/show_membres" name="show_membres")
     */
    public function adminShowMembresAction()
    {

    }

#--------------------------------------------#
    // supprime un membre via son ID et retourne à show_membres
    /**
     * @Route("/admin/delete_membre/{id} name="delete_membre")
     */
    public function adminDeleteMembreAction($id)
    {

    }

#--------------------------------------------#

}


